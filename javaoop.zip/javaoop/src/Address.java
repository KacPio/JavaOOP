public class Address {
    private String ulica;
    private String miasto;


    String get_ulica(){
        return ulica;
    }

    String get_miasto(){
        return miasto;
    }
    public Address(String ulica, String miasto){
        this.ulica = ulica;
        this.miasto = miasto;
    }
}
