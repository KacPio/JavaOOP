public class Kontakt {
    private int tel;
    private String mail;


    String get_mail(){
        return mail;
    }

    int get_tel(){
        return tel;
    }
    public Kontakt(int tel, String mail){
        this.tel = tel;
        this.mail = mail;
    }
}

