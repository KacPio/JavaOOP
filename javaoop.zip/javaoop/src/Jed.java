public class Jed {
    public static void main(String[] args) {

        User u = new User("Ryszard", "Kowal", 25, "kierowca");
        Address a = new Address("Bałtycka", "Olsztyn");
        Kontakt k = new Kontakt(520230421, "rkowa@wp.pl");

        System.out.println(u.get_imie());
        System.out.println(u.get_nazwisko());
        System.out.println(u.get_wiek());
        System.out.println(u.get_zawod());
        System.out.println(a.get_ulica());
        System.out.println(a.get_miasto());
        System.out.println(k.get_tel());
        System.out.println(k.get_mail());


    }
}