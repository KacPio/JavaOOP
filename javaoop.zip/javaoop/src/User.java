public class User {
    private String imie;
    private String nazwisko;
    private int wiek;
    private String zawod;



    String get_imie() {
        return imie;
    }



    String get_nazwisko() {
        return nazwisko;
    }



    int get_wiek() {
        return wiek;
    }



    String get_zawod() {
        return zawod;
    }
    public User(String imie, String nazwisko, int wiek, String zawod){
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.wiek = wiek;
        this.zawod = zawod;
    }
}
